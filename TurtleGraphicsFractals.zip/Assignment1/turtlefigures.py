from turtle import *
import graphics
import circle


# 1 binary tree
def tree(n,l,pen):
    # termination
    if n==0 or l<2:
       
       return
    #endif
    # recursion
    pen.forward(l);pen.color("pink"); circle.circle(n,l/6,pen);
    pen.color("white");
    pen.left(90)
    tree(n-1, l/2, pen);
    pen.right(45)
    tree(n-1, l/1.7, pen);
    pen.right(45)
    tree(n-1, l/1.5, pen);
    pen.right(45)
    tree(n-1, l/1.7, pen);
    pen.right(45)
    tree(n-1, l/2, pen);
    pen.left(90)
    pen.backward(l)
   
    
#end tree

# 2 dandelion
def dandelion(n,l,pen):
    #Termination
    if n == 0 or l < 2:
        return
    #recursion
    pen.forward(l)
    pen.left(120)   #trunk
    dandelion(n-1, l/2,pen)
    pen.right(30) 
    dandelion(n-1, l/2,pen)
    pen.right(30)     #petals
    dandelion(n-1, l/2,pen)
    pen.right(30)
    dandelion(n-1, l/2,pen)
    pen.right(30)
    dandelion(n-1, l/2,pen)
    pen.right(30)     #branch
    dandelion(n-1, l/2,pen)
    pen.right(30)
    dandelion(n-1, l/2,pen)
    pen.right(30)
    dandelion(n-1, l/2,pen)
    pen.right(30)
    dandelion(n-1, l/2,pen)
    pen.left(120)
    pen.backward(l)
    
#end dandelion


# 3 fern
def fern(n,l,pen):
    # termination
    if n==0 or l<2:
        return
    #endif
    # recursion
    pen.forward(l/2)
    pen.left(60); fern(n-1, l/2, pen); pen.color("white"); circle.circle(n,l/7,pen);pen.color("green");pen.right(60)
    pen.forward(l/2)
    pen.right(45); fern(n-1, l/2, pen); pen.color("white"); circle.circle(n,l/7,pen);pen.color("green"); pen.left(45)
    pen.forward(l)
    pen.right(10); fern(n-1, l/1.4, pen);pen.color("white");circle.circle(n,l/7,pen);pen.color("green"); pen.left(10)
    pen.backward(2*l)
#endfern

# 4 snowflake + anti-snowflake
def koch(n,l,pen):
    # termination
    if n==0 or l<2:
        pen.forward(l)
        return
    #endif
    # recursion
    koch(n-1,l/3, pen)
    pen.left(60)
    koch(n-1,l/3, pen)
    pen.right(120)
    koch(n-1,l/3,pen)
    pen.left(60)
    koch(n-1,l/3,pen)
#endkoch
    
def snowFlake(n,l,pen):
    for j in range(6):
        pen.left(180)
        koch(n,l,pen)
        pen.left(120)
        koch(n,l,pen)
    for i in range (1):
        pen.left(180)
        koch(n,l,pen)
        pen.right(180)
        
    #endfor
#endflake

# 5 gaskets
def gasket(n,l,pen):
    # termination 
    if n==0 or l<2:
        #equilateral triangle
        for i in range(3):
            pen.forward(l)
            pen.left(120)
            #endfor
            return
    #endif
    #recursion
    for i in range(3):
            gasket(n-1,l/2,pen)
            pen.forward(l)
            pen.left(120)
    #endfor
#endgasket



# 7 Andrews Cross
def andrew(n,l,pen):
    # termination
    if n==0 or l<2:
        pen.forward(l)
        return
    #endif
    # recursion
    andrew(n-1, l/3,pen)
    pen.left(90)
    andrew(n-1, l/3,pen)
    pen.right(90)
    andrew(n-1,l/3,pen)
    pen.right(90)
    andrew(n-1,l/3,pen)
    pen.left(90)
    andrew(n-1,l/3,pen)
    #endAndrew
def AndrewsCross(n,l,pen):
    for i in range(4):
        andrew(n,l,pen)
        pen.left(90)
    #endfor

def AndrewsCross2(n,l,pen):
    for i in range(4):
        andrew(n,l,pen)
        pen.right(90)
    #endfor
#endandrew

    



       
def cCurve(n,l,pen):
    
    if n>0:
        pen.right(45) 
        cCurve(n-1, l/2, pen) 
        pen.left(90)
        cCurve(n-1, l/2, pen) 
        pen.right(45) 
    else: pen.forward(l)
    

















    

