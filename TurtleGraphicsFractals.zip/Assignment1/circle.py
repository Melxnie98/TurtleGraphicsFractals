from graphics import*
from  turtle import *
from graphics import*
from  turtle import *

colors = ["mediumslateblue","indigo","darkmagenta","purple","darkmagenta","mediumorchid"]

#circles
def circle(n,l,pen):
    
    for i in range (6):
        pen.circle(l)
        pen.right(60)     
    
    
        
    
def sacredFlower(n,l,pen):
    for i in range (6):
        circle(n,l,pen)
        pen.color(colors[i%3])
        pen.up()
        pen.forward(l*1.75)
        pen.down()
        circle(n,l,pen)
        pen.up()
        pen.backward(l*1.75)
        pen.down()
        pen.right(60)
        pen.color(colors[i%3])
    

def flowerOfLife(n,l,pen):
    pen.color("WhiteSmoke")
    for i in range (6):
        circle(n,l,pen)
        pen.up()
        pen.forward(l*1.75)
        pen.down()
        circle(n,l,pen)
        pen.up()
        pen.backward(l*1.75)
        pen.down()
        pen.right(60)
        
    
    for j in range(6): 
        circle(n-1,l/2,pen)
        pen.forward(l*1.75) 
        circle(n-1,l/2,pen)
        pen.backward(l*1.75)
        pen.right(60)
        
        
    
        
        
        

        

        



        
      
        
        
        

    
    
    

        
        
  

        
       
    
