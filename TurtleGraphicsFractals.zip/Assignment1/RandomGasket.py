import random
from graphics import*
from  turtle import *
import math


colors=["gray","pink","white","purple","light blue","cyan"]

# gaskets
def randomGasket(n,l,pen):
    if n==0 or l<2:
        #equilateral triangle
        for i in range(3):
            pen.forward(l)
            pen.left(120)
            #endfor
            
        return
        
        #endif
        #recursion
    for j in range(3):
        randomGasket(n-1,l/2,pen)
        pen.forward(l)
        pen.left(120)
        pen.color(colors[j%6])
        #endfor
    #endgasket
            
