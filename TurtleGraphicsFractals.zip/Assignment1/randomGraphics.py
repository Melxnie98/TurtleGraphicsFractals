import math
import random
from graphics import *

# create the graphwin object
canvas = GraphWin("Random Graphics", 1000, 700)
canvas.setBackground("blue")
w, h = canvas.getWidth(), canvas.getHeight()

# function to draw random
def randomGraphics(n):
    # draw n random circles
    for i in range(n):
        # make a random circle
        x, y = random.randint(0,w), random.randint(0,h)
        radius = random.randint(20,300)
        circle = Circle(Point(x,y), radius)
        
        # random color and make a color
        red = random.randint(0,255)
        green = random.randint(0,255)
        blue = random.randint(0,255)
        circle.setFill(color_rgb(red, green, blue))

        circle.draw(canvas)
    #endfor
#end randomGraphics






        
        
        
