# squaregaskets
#list of colors
import random
import math
from graphics import*
from  turtle import *

colors = ["mediumslateblue","indigo","darkmagenta","purple","darkmagenta","mediumorchid"]

def squareGasket(n, l, pen):

    if n == 0 or l <3:
        # make square
        for i in range(4):
            pen.forward(l)
            pen.left(90)
            
            # endfor
        return

    for j in range(4):
        squareGasket(n-1 , l / 3, pen)
        pen.forward(l)
        pen.left(90)
        pen.forward(l)
        pen.color(colors[j%6])
        # end-for
    # endSquare gasket
