from tkinter import Canvas, Tk, IntVar, StringVar, mainloop, END,filedialog, Text,DoubleVar, Event,Frame
from tkinter.ttk import Label, Entry, OptionMenu, Button,LabelFrame,Scale,Style
from turtle import*
import graphics 
import turtlefigures
import RandomGasket
import SquareGasketcopy 
import circle


# create an empty frame and setup its geometry
root = Tk()
root.geometry("1000x700+200+200")
root.title("Turtle Interface")
root.configure(background='AliceBlue')


# create the canvas
canvasFrame = LabelFrame(root, text = "Turtle Canvas")
canvas = Canvas(canvasFrame, width = 600, height = 600)
canvas.pack()
canvasFrame.grid(row = 1, column = 0, rowspan = 8, columnspan = 3, padx = 20, pady = 20)


# make the screen
screen = TurtleScreen(canvas)
screen.bgcolor("thistle")

w, h = screen.screensize()

# make the pen
pen = RawTurtle(screen)
pen.shape("turtle")
pen.color("indigo")
pen.speed(0)
pen.width(1)

# contruct the interface


# make a control panel and grid it
controlPanel = LabelFrame(root, text="Control Panel")
controlPanel.grid(row = 0, column = 3, rowspan = 4, columnspan = 3, padx = 10, pady =10)


orderLabel = Label(controlPanel, text = "Order")
orderLabel.grid(row = 0, column = 0)
 
orderEntry = Entry(controlPanel)
orderEntry.grid(row = 0, column = 1, columnspan=2)

lengthLabel = Label(controlPanel, text = "Length")
lengthLabel.grid(row = 1, column = 0)
 
lengthEntry = Entry(controlPanel)
lengthEntry.grid(row = 1, column = 1, columnspan=2)

#Make speed slider
speed = DoubleVar()   
speedLabel = Label(controlPanel, text = "Speed")   
speedLabel.grid(row=2, column = 0)
speedSlider = Scale(controlPanel, from_=0, to=10, orient="horizontal",variable=speed)
def get_speed():
    return float(speedSlider.get())
speedSlider.grid(row=2, column = 1)

#Make sizeslider
size = DoubleVar()
sizeLabel = Label(controlPanel, text = "Pen Size")
sizeLabel.grid(row=3, column = 0)
sizeSlider = Scale(controlPanel, from_=0, to=10, orient="horizontal",variable=size)
sizeSlider.grid(row=3, column = 1)
def get_size():
    return float(sizeSlider.get())




# make an info panel and grid it
infoPanel = LabelFrame(root, text = "Information on the Design")
infoPanel.grid(row = 4, column = 3, rowspan = 4, columnspan = 3, padx = 10, pady =10)
text= Text(infoPanel,height=30, width=40, bg="lavender blush")
chars= text
#text.insert('end', '')
text.pack()

#Make the option menu drop down list
figureStr = StringVar(root)
figureList = ["Dandelion","Gasket","Square Gasket", "Sacred Flower", "Flower of Life","Andrews Cross", "Levy C Curve","Willow Branch", "Snowflake", "Cherry Blossom"]
#figure option menu defaults to dandelion if nothing is selected
figureOptionMenu = OptionMenu(controlPanel, figureStr, figureList[0],*figureList)
figureOptionMenu.grid(row = 4, column = 2, columnspan = 2)

#make the info txt

def onDrawF():
       
    #Changing the figure Id here toggles between the different styles in figureList
    # 0 = Dandelion, 1= Gasket etc
    figurestring = figureStr.get()
    print(figurestring)
    figureId = figureList.index(figurestring)
    order = int(orderEntry.get())
    length = int(lengthEntry.get())
    print(length)
    
    #what is the figure to draw
    #figureId = 1
    print(figureId, order, length)
    if figureId == 0:
        #text.insert('end', chars='This is a dandelion, It starts with a line and then breaks out into more lines at various angles with varying lengths. the putside branches are shorter to give it a more natural dandelion shape')
        text.delete('1.0','end')
        text.insert('end','\nThis is a dandelion.\nIt starts with a line and then breaks\nout into more lines at various angles\nwith varying lengths.\n Reccomended input values: 5,300 \nHowever, if pen size is increased a \nsmaller order value is reccomended.')
        screen.bgcolor("light blue")
        pen.color("white")
        pen.up()
        pen.left(90)
        pen.backward(h/2)
        pen.down()
        pen.speed(get_speed())
        print(speed)
        pen.width(get_size())
        print(width)
        turtlefigures.dandelion(order, length, pen)
        
    elif figureId == 1:
        text.delete('1.0','end')
        text.insert('end','\nThis is a triangular Sierpinski gasket.\n\nThe larger the length, the bigger the \ntriangle. \n\nIt draws smaller triangles with various colours inside. \n\nIt is an equilateral triangle.\n\nReccomended input values:5,500\n\nA larger pen is nice as it allows you\n to see the colours')
        screen.bgcolor("aquamarine3")
        pen.up()
        pen.right(90)
        pen.forward(h/3)
        pen.left(90)
        pen.backward(w/2.5)
        pen.down()
        pen.speed(get_speed())
        pen.width(get_size())
        RandomGasket.randomGasket(order, length, pen)
    elif figureId ==2:
        text.delete('1.0','end')
        text.insert('end','\nThis figure is a type of Sierpinski\ngasket.  \n\nThis time it is a square instead of a \ntriangle.  \n\nThis was acheived by using 90 degree \nangles and one extra recursive line than the \ntriangle. \n\nReccomended value inputs: 4,300 \n\nA slight increase in pen size is nice!')
        pen.up()
        pen.right(90)
        pen.forward(h/2)
        pen.left(90)
        pen.down()
        pen.speed(get_speed())
        pen.width(get_size())
        SquareGasketcopy.squareGasket(order, length, pen)
    elif figureId ==3:
        text.delete('1.0','end')
        text.insert('end','\nThis is a symbol of Sacred Geometry \nwhichrepresents the cycle of life.\n\nIt is said to encompass the most \nmeaningful patterns in our universe.\nMaybe that is why it took so long to get it right!\n \nReccomended input values: 3,80 \n \nThe length value should be lower as \nit is a radius meaning the size will\ndouble. \nIt also looks a little nicer with a \nbigger pen size')
        screen.bgcolor("black")
        pen.speed(get_speed())
        pen.width(get_size())
        circle.sacredFlower(order, length, pen)
    elif figureId ==4:
        text.delete('1.0','end')
        text.insert('end','\nThis is an elaboration of the Sacred \nFlower.\nThis version has smaller versions of \nitself.\nIt also leaves the trail lines to add \nmore detail rather than using \npen.up() and pen.down()\n\nReccomended input values: 3,80')
        pen.speed(get_speed())
        screen.bgcolor("PaleVioletRed")
        pen.color("WhiteSmoke")
        pen.width(get_size())
        circle.flowerOfLife(order, length, pen)
    elif figureId ==5:
        text.delete('1.0','end')
        text.insert('end','\nThis figure is a recursive cross.\n\nIt uses a recursive function and \nand then turns back on itself and \nrepeats to give the design on two sides.\n\nReccomended input values: 6,500\n\nIt is more detailed the higher the order \nnumber however this slows the process!')
        pen.up()
        pen.backward(w/2)
        pen.right(90)
        pen.forward(h/2)
        pen.left(90)
        pen.down()
        pen.speed(get_speed())
        pen.width(get_size())
        turtlefigures.AndrewsCross(order, length, pen)
    elif figureId ==6:
        text.delete('1.0','end')
        text.insert('end','\nThe Levy C Curve starts with a line\nThe line is then replaced with two \nlines and a 45 degree angle\nThe more splits that happen the nicer \nthe fractal\nReccomended input values: 10,6000\nLength value must be high to see the \ndetail as recursion effects the length.')
        pen.speed(get_speed())
        pen.width(get_size())
        pen.up()
        pen.backward(w/3)
        pen.down()
        screen.bgcolor("turquoise")
        pen.color("black")
        turtlefigures.cCurve(order, length, pen)
    elif figureId == 7:
        text.delete('1.0','end')
        text.insert('end','\nThis figure is based on a willow branch. \n\nI changed the direction and colour and \nadded some white circles for their \nspring fluff! \n\nReccomended input values: 5,150\n\n(For a more speedy experiance 3,150)')
        screen.bgcolor("light gray")
        pen.up()
        pen.left(90)
        pen.color("green")
        pen.fillcolor('white')
        pen.backward(h/2)
        pen.down()
        pen.speed(get_speed())
        pen.width(get_size())
        turtlefigures.fern(order, length, pen)
    elif figureId == 8:
        pen.up()
        pen.forward(w/2)
        pen.down()
        pen.color("white")
        screen.bgcolor("black")
        text.delete('1.0','end')
        text.insert('end','\nThis figure is inspired by the Koch \ncurve. \n\nIt is a snowflake built from recursive \nlines set at an angle to make five \ndecorative points. \n\nReccomended input values: 5,300(for \ndetail) 2,300(for speed)')
        pen.speed(get_speed())
        pen.width(get_size())
        turtlefigures.snowFlake(order, length, pen)
    elif figureId == 9:
        text.delete('1.0','end')
        text.insert('end','\nThis figure incorporates the basic tree \nfigure and adds a flower originally \nbuilt for figure 4.\n\nI decided to add the two together in \norder to get a cherry blossom tree. \n\nRecommended input values: 3,200')
        screen.bgcolor("gray")
        pen.color("white")
        pen.up()
        pen.left(90)
        pen.backward(h/2)
        pen.down()
        pen.speed(get_speed())
        pen.width(get_size())
        turtlefigures.tree(order, length, pen) 
 #end on draw
drawButton = Button(controlPanel, text = "Draw", command = onDrawF)
drawButton.grid(row = 4, column = 1)  

 
def onClearF():
    
    orderEntry.delete(0,0)
    lengthEntry.delete(0,0)
    screen.reset()
    screen.bgcolor("thistle")
    pen.home()
    pen.color("indigo")
    pen.speed(0)
    pen.width(3)
    screen.mainloop()       
clearButton = Button(controlPanel, text = "Clear", command = onClearF)
clearButton.grid(row = 4, column = 0)

root.mainloop()
